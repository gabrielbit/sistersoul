<?php
/**
 * IceMegaMenu Extension for Joomla 1.6 By IceTheme
 * 
 * 
 * @copyright	Copyright (C) 2008 - 2011 IceTheme.com. All rights reserved.
 * @license		GNU General Public License version 2
 * 
 * @Website 	http://www.icetheme.com/Joomla-Extensions/icemegamenu.html
 * @Support 	http://www.icetheme.com/Forums/IceMegaMenu/
 *
 */
 
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>

Copyright and disclaimer
---------------------------
This application is opensource software released under the GPL.  Please
see source code and the LICENSE file.


Changelog
------------
-------------------- 1.7.1 Stable Release [3-February-2012] ----------------

	#- added CSS3 theme
		you can use only css for your icemegamenu module.

-------------------- 1.7.0 Stable Release [12-October-2011] ----------------
	#- We have fixed this BUG
		#148 Can`t have more than one IceMegaMenu Module on the same page.
    #- We have fixed this BUG
		#137 Adding special characters-IceMegaMenu doesn`t work.
	#- We have fixed this BUG
		#132 Notice: Undefined offset: -1 in D:\wamp\www\icethemev4\modules\mod_icemegamenu\libs\menucore.php on line 434
	#- We have fixed ice_megamenu dropdown position after  screen resizing.
		
	
-------------------- 1.6.0 Stable Release [18-March-2011] ------------------
    