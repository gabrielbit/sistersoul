<?php
/**
 * @Author		Mahesh Rangana Range
 * @version		music.php 2010-09-25 
 * @package		Joomla
 * @subpackage	Music
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */
defined( '_JEXEC' ) or die( 'Restricted access' );

//import joomla data model liabraries
jimport( 'joomla.application.component.model' );
class ModelMusicMusic extends JModel
	{
		//underscore reminds us that it is a protected variabl
		var $_Musics = null;
		 var $_pagination = null;
		
		
	function __construct()
 	 {
        parent::__construct();
 
        global $mainframe, $option;
 
        // Get pagination request variables
		$limit =10;
        $limitstart = JRequest::getVar('limitstart', 0, '', 'int');
 
         //In case limit has been changed, adjust it
        $limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
 
        $this->setState('limit', $limit);
        $this->setState('limitstart', $limitstart);
  }
		
		
		function getList()
			{
				if(!$this->_Musics)
					{
					$query = "SELECT * FROM #__music WHERE published = '1'";
					//_getList() interprets two zeros as get all rows
					$this->_Musics= $this->_getList($query,$this->getState('limitstart'),$this->getState('limit')); 
					}
				return $this->_Musics;
			}
			
			
function getPagination()
  {
        // Get pagination request variables
        // Load the content if it doesn't already exist
        if (empty($this->_pagination)) {
            jimport('joomla.html.pagination');
			$db =& JFactory::getDBO();
			$query = "SELECT count(*) FROM #__music WHERE published = '1'";
			$db->setQuery( $query );
			$total = $db->loadResult();
			
           
			$this->_pagination = new JPagination($total ,$this->getState('limitstart'), $this->getState('limit') );
        }
        return $this->_pagination;
  }

			
	}
?>