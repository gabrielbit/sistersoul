<?php
/**
 * @Author		Mahesh Rangana Range
 * @version		toolbar.music.php 2010-09-25 
 * @package		Joomla
 * @subpackage	Music
 * @copyright	Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */
defined( '_JEXEC' ) or die( 'Restricted access' );
function MusicBuildRoute(&$query)
{

	$segments = array();
       if(isset( $query['option'] ))
       {
	   			$getmusic=explode( '_', $query['option'] );
                $segments[] =$getmusic[1] ;
                unset( $query['option'] );
       };
       if( isset($query['Itemid']) )
       {
                $segments[] = $query['Itemid'];
                unset( $query['Itemid'] );
       };
       unset( $query['view'] );
       return $segments;

}


function MusicParseRoute($segments)
{
$vars = array();
       $menu	= &JSite::getMenu();
	   $item	= &$menu->getActive();
       // Count segments
	   echo $item;
       $count = count( $segments );
       //Handle View and Identifier
       switch( $item�>$query['view'] )
       {
               case 'option':
                       $id   = explode( ':', $segments[$count-1] );
                       $vars['id']   = (int) $id[0];
                       $vars['view'] = 'music';
                       break;
       }
       return $vars;

}

