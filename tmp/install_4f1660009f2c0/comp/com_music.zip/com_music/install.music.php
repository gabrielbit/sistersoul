<?php
/**
 * @Author		Mahesh Rangana Range
 * @version		install.music.php 2010-09-25 
 * @package		Joomla
 * @subpackage	Music
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */
defined( '_JEXEC' ) or die( 'Restricted access' );
function com_install()
{
?>
<div class="header">Congratulations, Installation is completed</div>
<p>
Please folow these steps to use this components.</p>
<ul>
  <li>There is a directory named audio inside the components\com_music path.</li>
  <li>Add your mp3 audio files and images to the audio folder</li>
  <li>Then those name add to the song and image feilds when adding music.</li>
</ul>

Thank you for the using this component and feel free to send me the feedback .
<ul>
<li>Conatct - Mahesh Rangana Range</li>
<li>E-mail - <a href="mailto:mashtharufit@gmail.com">mashtharufit@gmail.com</a></li>
<li>Skype name - mashfit </li>
</ul>
<?php
}
?>