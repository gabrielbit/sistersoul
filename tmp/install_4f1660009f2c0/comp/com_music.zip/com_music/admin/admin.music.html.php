<?php
/**
 * @Author		Mahesh Rangana Range
 * @version		admin.music.html.php 2010-09-25 
 * @package		Joomla
 * @subpackage	Music
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 *contain the actual HTML output
 */
 
defined( '_JEXEC' ) or die( 'Restricted access' );

class HTML_music
	{
		
	function editMusic( $row, $lists, $option )
	{
		
		?>
		<form action="index.php" method="post" name="adminForm" id="adminForm">
		<fieldset class="adminform">
			<legend>Song Details</legend>
			<table class="admintable">
            <tr><td width="100"></td>
            <td>
            Inside the component has a dir name audio <br/>
            upload your audio file and image to the audio directory<br/>
            then you must put that names to the song and image fields.</td></tr>
		<tr>
			<td width="100" align="right" class="key">
				Musician Name:
			</td>
			<td>
			<input class="text_area" type="text" name="name" id="name" 
       		 size="50" maxlength="250" value="<?php echo $row->name;?>" />
			</td>
		</tr>

		<tr>
			<td width="100" align="right" class="key">
				Notes:
			</td>
			<td>
			<textarea class="text_area" cols="20" rows="4" name="notes" 
			id="notes" style="width:500px"><?php echo $row->notes; ?></textarea>
			</td>
		</tr>

		<tr>
			<td width="100" align="right" class="key">
				Song Name:
				</td>
			<td>
				<input class="text_area" type="text" name="song" id="song"
 				size="50" maxlength="250" value="<?php  echo $row->song;?>"/> eg .waka.mp3
			</td>
		</tr>
        

		<tr>
			<td width="100" align="right" class="key">
				Image Name:
			</td>
			<td>
				<input class="text_area" type="text" name="images" id="images"
 				size="50" maxlength="250" value="<?php  echo $row->images;?>"/>eg .waka.jpg
			</td>
		</tr>

		<tr>
			<td width="100" align="right" class="key">
				Published:
			</td>
			<td>
			<?php	echo $lists['published']; ?>
			</td>
		</tr>
        
</table>
</fieldset>

		<input type="hidden" name="id" value="<?php echo $row->id; ?>" />
		<input type="hidden" name="option" value="<?php echo $option;?>" />
		<input type="hidden" name="task" value="" />
		</form>
	<?php
	}




//put a and tag to take the object reference
function showMusic( $option, &$rows,&$pageNav )
	{
		?>
	<form action="index.php" method="post" name="adminForm">
	<table class="adminlist">
	<thead>
	<tr>
			<th width="20">
            <!--count row add to select all  -->
			<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $rows ); ?>);" />
			</th>
            
			<th class="title">Name</th>
			<th width="30%">Discription</th>
			<th width="15%">song</th>
			<th width="15%">image</th>
			<th width="5%" nowrap="nowrap">Published</th>
	</tr>
	</thead>
    
	<?php
	$k = 0;
	for ($i=0, $n=count( $rows ); $i < $n; $i++)
		{
			$row = &$rows[$i];
			$checked = JHTML::_('grid.id', $i, $row->id );
			$published = JHTML::_('grid.published', $row, $i );
			$link= JRoute::_( 'index.php?option=' .$option . '&task=edit&cid[]='. $row->id );
		?>
        
	<tr class="<?php echo "row$k"; ?>">
		<td>
			<?php  echo $checked; ?>
		</td>
		<td>
			<a href="<?php echo $link; ?>">
			<?php echo $row->name; ?></a>
		</td>

		<td>
			<?php echo $row->notes; ?>
		</td>
		<td>
			<?php echo $row->song; ?>
		</td>
		<td>
			<?php  echo $row->images; ?>
		</td>
		<td align="center">
			<?php echo $published;?>
		</td>
	</tr>
    
	<?php
		$k = 1 - $k;
	}
?>

	<tfoot>
		<td colspan="7">
			<?php 
			//getListFooter() member function of $pageNav returns HTML for
			//links to each of the pages
				echo $pageNav->getListFooter();
 		?></td>
	</tfoot>

</table>

	<input type="hidden" name="option" value="<?php echo $option;?>" />
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="boxchecked" value="0" />
	</form>
	<?php
	}

}
?>