<?php
/**
 * @Author		Mahesh Rangana Range
 * @version		admin.music.php 2010-09-25 
 * @package		Joomla
 * @subpackage	Music
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 *contain the actual HTML output
 */


defined ('_JEXEC') or die ('Restricted action');

/*returns the absolute path to the
corresponding component files

*/
require_once(JApplicationHelper::getPath('admin_html'));
require_once( JPATH_COMPONENT.DS.'controller.php' );

JTable::addIncludePath(JPATH_COMPONENT.DS.'tables'); 

//passed an array into the controller constructor. This array has a
//value for default_task
$controller = new MusicController(array('default_task' => 'showMusic') );

//task request variable here to tell the controller which member
//function to call
$controller->execute( JRequest::getVar( 'task' ) );
//redirect() member function to forward the user to any URL set by setRedirect().
$controller->redirect();

?>