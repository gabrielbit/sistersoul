<?php
/**
 * @Author		Mahesh Rangana Range
 * @version		music.php 2010-09-25 
 * @package		Joomla
 * @subpackage	Music
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */

defined('_JEXEC') or die ('Restrictes action');

class TableMusic extends JTable
{

/*
all the columns of the database table as
member variables and set them to null

*/
	var $id = null;
	var $name = null;
	var $notes = null;
	var $song = null;
	var $images = null;
	var $published = null;
	
	
	
	function __construct(&$db)
	{
		parent::__construct( '#__music', 'id', $db );
		
	}

}

?>