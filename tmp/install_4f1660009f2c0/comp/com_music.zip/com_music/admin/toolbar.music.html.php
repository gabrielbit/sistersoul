<?php
/**
 * @Author		Mahesh Rangana Range
 * @version		toolbar.music.html.php 2010-09-25 
 * @package		Joomla
 * @subpackage	Music
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */


defined ('_JEXEC') or die ("Restricted Action");
/*
all the core components implement toolbars with similar
buttons for saving, deleting, editing, and publishing items


*/
class TOOLBAR_music
{

	function _NEW()
	{
		/*
		class JToolBarHelper contains functions that generate all the HTML necessary
		to build toolbars
		open when add new page
		*/
		JToolBarHelper::save();
		JToolBarHelper::apply();
		JToolBarHelper::cancel();
		
	}
	
	function _DEFAULT()
	{
		/*
		default view. add name and image
		add other tool bar button
		JText ::_() used to add text in joomla
		
		*/
		JToolBarHelper::title(JText::_('Mp3 controler'),'generic.png');
		JToolBarHelper::publishList();
		JToolBarHelper::unpublishList();
		JToolBarHelper::editList();
		JToolBarHelper::deleteList();
		JToolBarHelper::addNew();
	}
}

?>