<?php
/**
 * @Author		Mahesh Rangana Range
 * @version		toolbar.music.php 2010-09-25 
 * @package		Joomla
 * @subpackage	Music
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */


defined('_JEXEC') or die ("Restricted action");

/*
call to getPath() allows you to call up the
toolbar.music.html.php file without committing to a component name.
required_once execute file at once
*/

require_once(JApplicationHelper::getPath('toolbar_html'));

/*
request variable $task is automatically
registered in global scope by Joomla!
*/

switch($task)
{
case  'edit' :
case 'add':
	TOOLBAR_music :: _NEW();
	break;
	
default:
	TOOLBAR_music :: _DEFAULT();	
	break;

}



?>