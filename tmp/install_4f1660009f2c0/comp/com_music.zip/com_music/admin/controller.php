<?php
/**
 * @Author		Mahesh Rangana Range
 * @version		controler.php 2010-09-25 
 * @package		Joomla
 * @subpackage	Music
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 *contain the actual HTML output
 */
 
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.controller' );
class MusicController extends JController
{
	function __construct( $default = array() )
	{
		parent::__construct( $default );
		$this->registerTask( 'add' , 'edit' );
		$this->registerTask( 'apply', 'save' );
		$this->registerTask( 'unpublish', 'publish' );
	}
	
	
	
	function publish()
	{
		global $option;
		$cid = JRequest::getVar( 'cid', array(), '', 'array' );
		if( $this->_task == 'publish')
			{
				$publish = 1;
			}
		else
			{
				$publish = 0;
			}
		$musicTable =& JTable::getInstance('music', 'Table');
		$musicTable->publish($cid, $publish);
		$this->setRedirect( 'index.php?option=' . $option );
	}
	
	function edit()
	{
		global $option;
		$row =& JTable::getInstance('music', 'Table');
		$cid = JRequest::getVar( 'cid', array(0), '', 'array' );
		$id = $cid[0];
		$row->load($id);
		$lists = array();
		

		$lists['published'] = JHTML::_('select.booleanlist', 'published','class="inputbox"', $row->published);
		HTML_music::editMusic($row, $lists, $option);
		}
		
		
function save()
	{
		global $option;
		$row =& JTable::getInstance('music', 'Table');
		if (!$row->bind(JRequest::get('post')))
			{
				echo "<script> alert('".$row->getError()."');
				window.history.go(-1); </script>\n";
				exit();
			}
			

			if (!$row->store()) {
			echo "<script> alert('".$row->getError()."'); window.history.
			go(-1); </script>\n";
			exit();
			}
			
			switch ($this->_task)
				{
				case 'apply':
				$msg = 'Changes to Details saved';
				$link = 'index.php?option=' . $option .'&task=edit&cid[]='. $row->id;
				break;
				case 'save':
				default:
				$msg = 'Music Saved';
				$link = 'index.php?option=' . $option;
				break;
				}
			$this->setRedirect($link, $msg);
		}
		
		
		
		
function showMusic()
	{
		
		global $option, $mainframe;
		
		//number of records,it get it from the config file
		$limit = JRequest::getVar('limit',$mainframe->getCfg('list_limit'));
		//record starting
		$limitstart = JRequest::getVar('limitstart', 0);
		
		
		$db =& JFactory::getDBO();
		$query = "SELECT count(*) FROM #__music";
		$db->setQuery( $query );
		$total = $db->loadResult();
		
		$query = "SELECT * FROM #__music";
		/*$db->setQuery( $query );*/
		$db->setQuery( $query, $limitstart, $limit );
		$rows = $db->loadObjectList();
		if ($db->getErrorNum()) {
			echo $db->stderr();
			return false;
			}
			
		
		/*HTML_music::showMusic( $option, $rows );*/
		jimport('joomla.html.pagination');
		$pageNav = new JPagination($total, $limitstart, $limit);
		HTML_music::showMusic( $option, $rows, $pageNav );
	}
	
	
function remove()
	{
		global $option;
		$cid = JRequest::getVar( 'cid', array(), '', 'array' );
		$db =& JFactory::getDBO();
		if(count($cid))
			{
				$cids = implode( ',', $cid );
				$query = "DELETE FROM #__music WHERE id IN ( $cids )";
				$db->setQuery( $query );
				if (!$db->query()) {
				echo "<script> alert('".$db->getErrorMsg()."'); window.
				history.go(-1); </script>\n";
					}
			}
		$this->setRedirect( 'index.php?option=' . $option );
	}
}

?>