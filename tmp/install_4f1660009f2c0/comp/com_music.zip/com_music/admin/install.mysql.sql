CREATE TABLE IF NOT EXISTS #__music(
id INT NOT NULL auto_increment,
name VARCHAR(255) NOT NULL,
notes text NOT NULL,
song varchar(255) NOT NULL,
images varchar(255),
published tinyint(1) NOT NULL default '0',
PRIMARY KEY (id)
)

