<?php
/**
 * @Author		Mahesh Rangana Range
 * @version		uninstall.music.php 2010-09-25 
 * @package		Joomla
 * @subpackage	Music
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */
defined( '_JEXEC' ) or die( 'Restricted access' );
function com_uninstall()
{
?>
<div class="header">The music component are now removed from
your system.</div>
<p>Please provide me a feedback that help me to enhance this component.</p>
<ul>
  <li>Contact  - Mahesh Rangana</li>
  <li>E-mail - <a href="mailto:mashtharufit@gmail.com">mashtharufit@gmail.com</a></li>
  <li>Skype name - mashfit </li>
</ul>
<?php
}
?>