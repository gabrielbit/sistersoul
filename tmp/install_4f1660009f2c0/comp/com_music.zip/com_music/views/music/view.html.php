<?php
/**
 * @Author		Mahesh Rangana Range
 * @version		view.html.php 2010-09-25 
 * @package		Joomla
 * @subpackage	Music
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport('joomla.application.component.view');
class MusicViewMusic extends JView
{
function display($tpl = null)
{
global $option;
//calling to the model
$model = &$this->getModel();
//calling to the function
$list = $model->getList();
$pagination = $model->getPagination();

//Data is pushed into the template using the JView::assignRef method
$this->assignRef('list', $list);
$this->assignRef('pagination', $pagination);
parent::display($tpl);
}
}
?>