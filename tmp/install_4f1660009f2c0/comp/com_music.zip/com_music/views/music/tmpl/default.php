<?php 
/**
 * @Author		Mahesh Rangana Range
 * @version		default.php 2010-09-25 
 * @package		Joomla
 * @subpackage	Music
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */
 
defined( '_JEXEC' ) or die( 'Restricted access' ); 
$baseUrl = JURI::base();
if(count($this->list)>0)
{
?>
<table style="border-collapse:collapse; border:0px">
<thead bgcolor="#CCCCCC">
	<tr bgcolor="#CCCCCC">
			<th width="20%">Photo</th>
			<th width="15%">Name</th>
			<th width="45%">Discription</th>
			<th width="20%" >Song</th>
	</tr>
</thead>

<?php foreach($this->list as $l): ?>
<tr><td>
<?php 
$modUrl = $baseUrl.'components/com_music/audio/';
echo '<img src="'.$modUrl.$l->images .'" style="width:100px; height:100px"</img>'; ?>
</td><td>
<?php echo $l->name; ?>
</td><td>
<?php echo $l->notes; ?>
</td>
<td>
<?php 
$playerUrl=$baseUrl.'components/com_music/audio/';
			$player1 = '<object type="application/x-shockwave-flash" data="'.$playerUrl.'player1.swf" width="170"
				 height="30"  showvolume="1">
				 
				<param name="wmode" value="transparent" />
				<param name="movie" value="'.$modUrl.'player1.swf" />
				<param name="FlashVars" value="mp3='.$modUrl.$l->song.'&amp;autoplay=0&amp;loop=0&amp;showstop=1&amp;showvolume=1;" />
				<p>There seems to be an error with the player !</p>
				</object>';
				echo $player1 ;
				 ?>
</td>

</tr>
<?php endforeach; ?>
<tfoot>
    <tr>
      <td> </td><td> </td><td colspan="5"><?php echo $this->pagination->getPagesLinks()
;
	   ?></td></tr>
       <tr>
         <td></td><td></td><td><strong></strong></td><td><img src="http://www.gnu.org/graphics/lgplv3-88x31.png"></img></td>
    </tr>
  </tfoot>

</table>
<?php } ?>