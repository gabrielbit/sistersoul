<?php
/**
 * @Author		Mahesh Rangana Range
 * @version		controler.php 2010-09-25 
 * @package		Joomla
 * @subpackage	Music
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 *contain the actual HTML output
 */

defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.controller' );
class MusicController extends JController
{

	function display()
	{
		//get a reference to the current document object
		$document =& JFactory::getDocument();
		//what part will show ,2nd is the folder name
		$viewName = JRequest::getVar('view', 'music');
		//type access public
		$viewType = $document->getType();
		
		//setting the view name and access
		$view = &$this->getView($viewName, $viewType);
		
		//setting the model
		$model =& $this->getModel( $viewName, 'ModelMusic' );
		
		if (!JError::isError( $model ))
		 {
			$view->setModel( $model, true );
		}
		$view->setLayout('default');
		$view->display();
	}
}?>