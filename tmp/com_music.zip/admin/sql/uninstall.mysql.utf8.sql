DROP TABLE IF EXISTS #__music_artist;
DROP TABLE IF EXISTS #__music_album;
DROP TABLE IF EXISTS #__music_song;
DROP TABLE IF EXISTS #__music_artistalbums;
DROP TABLE IF EXISTS #__music_albumsongs;
DROP TABLE IF EXISTS #__music;
