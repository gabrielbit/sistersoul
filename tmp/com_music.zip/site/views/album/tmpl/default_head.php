<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted Access');
?>
<tr>
<th>
    <?php echo JText::_('COM_MUSIC_SONG_NUMBER_LABEL'); ?>
</th>
<th>
    <?php echo JText::_('COM_MUSIC_SONG_NAME_LABEL'); ?>
</th>
</tr>
